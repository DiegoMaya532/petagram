package com.diegomaya532.petagram_s3c3;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

public class AdaptadorMascota extends RecyclerView.Adapter<AdaptadorMascota.MascotasViewHolder>{
    ArrayList<Mascota> mascotas;
    Activity activity;
    //CONSTRUCTOR
    public AdaptadorMascota(ArrayList mascotas, Activity activity){
        this.mascotas = mascotas;
        this.activity = activity;
    }
    @Override
    public MascotasViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.cardview_mascota, viewGroup, false);
        return new MascotasViewHolder(v);
    }

    @Override
    public void onBindViewHolder( MascotasViewHolder mascotasViewHolder, int i) {
        final Mascota mascota = mascotas.get(i);
        mascotasViewHolder.imgMascota.setImageResource(mascota.getImagen());
        mascotasViewHolder.tvNombre.setText(mascota.getNombre());
        mascotasViewHolder.tvRaiting.setText(mascota.getRaiting());
    }

    @Override
    public int getItemCount() {
        return mascotas.size();
    }

    //CLASE ESTÁTICA VIEW HOLDER
    public static class MascotasViewHolder extends RecyclerView.ViewHolder{
        //DECLARACIONES
        private ImageView imgMascota;
        private TextView tvNombre;
        private TextView tvRaiting;
        //CONSTRUCTOR DE LA CLASE ESTÁTICA
        public MascotasViewHolder(View itemView) {
            super(itemView);
            imgMascota = (ImageView)itemView.findViewById(R.id.imgMascotaCV);
            tvNombre = (TextView)itemView.findViewById(R.id.tvNombreMascotaCV);
            tvRaiting = (TextView) itemView.findViewById(R.id.tvRaitingMascotaCV);
        }
    }
}

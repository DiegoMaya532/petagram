package com.diegomaya532.petagram_s3c3;

public class Mascota {
    //VARIABLES
    private String nombre;
    private String raiting;
    private int imagen;
    //CONSTRUCTOR
    public Mascota(String nombre, String raiting, int imagen){
        this.nombre = nombre;
        this.raiting = raiting;
        this.imagen = imagen;
    }
    //GETTERS AND SETTERS
    public String getNombre() {
        return nombre;
    }
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    public int getImagen() {
        return imagen;
    }
    public void setImagen(int imagen) {
        this.imagen = imagen;
    }
    public String getRaiting() {
        return raiting;
    }
    public void setRaiting(String raiting) {
        this.raiting = raiting;
    }
}

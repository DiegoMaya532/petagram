package com.diegomaya532.petagram_s3c3;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.ArrayList;

import static com.diegomaya532.petagram_s3c3.R.layout.activity_main;

public class MainActivity extends AppCompatActivity {
    ArrayList<Mascota> mascotas;
    private RecyclerView listaMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(activity_main);
            android.support.v7.widget.Toolbar miToolBar = findViewById(R.id.miActionBar);
            setSupportActionBar(miToolBar);
            getSupportActionBar().setDisplayShowTitleEnabled(false);
            listaMascotas = findViewById(R.id.rvMascotas);
            LinearLayoutManager llm = new LinearLayoutManager(this);
            llm.setOrientation(LinearLayoutManager.VERTICAL);
            listaMascotas.setLayoutManager(llm);
            mascotas = new ArrayList<Mascota>();
            mascotas.add(new Mascota("Jack", "5", R.drawable.dog_00));
            mascotas.add(new Mascota("Ronnie", "1", R.drawable.dog_01));
            mascotas.add(new Mascota("Bella", "3", R.drawable.dog_02));
            mascotas.add(new Mascota("Husher", "2", R.drawable.dog_03));
            mascotas.add(new Mascota("Rocket", "4", R.drawable.dog_04));
            AdaptadorMascota adaptadorMascota = new AdaptadorMascota(mascotas, this);
            listaMascotas.setAdapter(adaptadorMascota);
        ImageView iv = findViewById(R.id.imgStar);
        iv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, TopMascotas.class);
                startActivity(intent);
                //Toast.makeText(MainActivity.this, "Presionado", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String ide = Integer.toString(item.getItemId());
        Toast.makeText(MainActivity.this, "Presionado: "+ide, Toast.LENGTH_SHORT).show();
        return super.onOptionsItemSelected(item);
    }
}
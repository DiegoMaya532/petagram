package com.diegomaya532.petagram_s3c3;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;

public class TopMascotas extends AppCompatActivity {
    private RecyclerView rvTopMascotas;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_top_mascotas);
        android.support.v7.widget.Toolbar miToolBar = (android.support.v7.widget.Toolbar) findViewById(R.id.miChildActionBar);
        setSupportActionBar(miToolBar);
        getSupportActionBar().setDisplayShowTitleEnabled(false);
        ActionBar ab = getSupportActionBar();
        ab.setDisplayHomeAsUpEnabled(true);
        rvTopMascotas = (RecyclerView)findViewById(R.id.rvMascotasTop);
        LinearLayoutManager llm = new LinearLayoutManager(this);
        llm.setOrientation(LinearLayoutManager.VERTICAL);
        rvTopMascotas.setLayoutManager(llm);
        ArrayList<Mascota> mascotasTop = new ArrayList<Mascota>();
        mascotasTop.add(new Mascota("Ronnie", "1", R.drawable.dog_01));
        mascotasTop.add(new Mascota("Husher", "2", R.drawable.dog_03));
        mascotasTop.add(new Mascota("Bella", "3", R.drawable.dog_02));
        mascotasTop.add(new Mascota("Rocket", "4", R.drawable.dog_04));
        mascotasTop.add(new Mascota("Jack", "5", R.drawable.dog_00));
        AdaptadorMascota adaptadorMascota = new AdaptadorMascota(mascotasTop, this);
        rvTopMascotas.setAdapter(adaptadorMascota);
    }
}